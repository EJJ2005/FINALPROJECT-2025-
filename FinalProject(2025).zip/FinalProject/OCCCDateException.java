package exceptions;

public class OCCCDateException extends Exception {
    public OCCCDateException(String message) {
        super(message);
    }
}
