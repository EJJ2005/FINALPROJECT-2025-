package model;

public class RegisteredPerson extends Person {
    public RegisteredPerson(String firstName, String lastName) {
        super(firstName, lastName);
    }
}

